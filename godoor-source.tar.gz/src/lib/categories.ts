import {
  UtensilsCrossed, ShoppingCart, Pill, Shirt, Package, FileText,
  Smartphone, Wrench, Sparkles, Fuel, Wine, Sprout, Car, BookOpen,
  Flower2, Dog, Gamepad2, Baby, Scissors, Camera, Gift, GraduationCap,
  Building2, Beef, Coffee, Pizza, Apple, HeartPulse, Droplets, Bike,
  HandPlatter, Flame, CookingPot, Nut, Cookie, ShoppingBag, Truck,
  Armchair, BedDouble, Lamp, Sofa, Table, WashingMachine, Refrigerator,
  Headphones, Laptop, Monitor, CarFront, Bus, Landmark
} from "lucide-react";

export type CategoryInfo = {
  id: string;
  label: string;
  icon: typeof UtensilsCrossed;
  color: { bg: string; text: string };
  products: { name: string; price: number }[];
};

export const CATEGORIES: CategoryInfo[] = [
  {
    id: "Food & Restaurants",
    label: "Food & Restaurants",
    icon: UtensilsCrossed,
    color: { bg: "bg-amber-500/10", text: "text-amber-500" },
    products: [
      { name: "Rolex", price: 3000 },
      { name: "Chapati", price: 2000 },
      { name: "Chicken & Chips", price: 15000 },
      { name: "Fries", price: 5000 },
      { name: "Rice & Beans", price: 5000 },
      { name: "Posho & Beans", price: 3000 },
      { name: "Matooke & Groundnut Sauce", price: 5000 },
      { name: "Fish & Cassava", price: 10000 },
      { name: "Soda", price: 2000 },
      { name: "Water Bottle", price: 1000 },
      { name: "Juice", price: 3000 },
      { name: "Milk", price: 2000 },
    ],
  },
  {
    id: "Groceries & Market",
    label: "Groceries & Market",
    icon: ShoppingCart,
    color: { bg: "bg-emerald-500/10", text: "text-emerald-500" },
    products: [
      { name: "Sugar (1kg)", price: 5000 },
      { name: "Salt (500g)", price: 2000 },
      { name: "Cooking Oil (1L)", price: 8000 },
      { name: "Bar Soap", price: 3000 },
      { name: "Bread", price: 3000 },
      { name: "Milk (1L)", price: 3000 },
      { name: "Eggs (tray)", price: 10000 },
      { name: "Tomatoes (1kg)", price: 4000 },
      { name: "Onions (1kg)", price: 3000 },
      { name: "Posho (5kg)", price: 8000 },
      { name: "Rice (2kg)", price: 7000 },
      { name: "Bean Flour", price: 5000 },
    ],
  },
  {
    id: "Pharmacy",
    label: "Pharmacy",
    icon: Pill,
    color: { bg: "bg-blue-500/10", text: "text-blue-500" },
    products: [
      { name: "Panadol (pack)", price: 3000 },
      { name: "Crocin (pack)", price: 3500 },
      { name: "Amoxicillin", price: 5000 },
      { name: "ORS Sachets", price: 2000 },
      { name: "Bandage Roll", price: 2500 },
      { name: "Digital Thermometer", price: 25000 },
      { name: "Multivitamins", price: 8000 },
      { name: "Cough Syrup", price: 6000 },
      { name: "Mosquito Net", price: 15000 },
      { name: "Sunscreen", price: 10000 },
      { name: "Blood Pressure Monitor", price: 45000 },
      { name: "First Aid Kit", price: 20000 },
    ],
  },
  {
    id: "Clothing & Fashion",
    label: "Clothing & Fashion",
    icon: Shirt,
    color: { bg: "bg-purple-500/10", text: "text-purple-500" },
    products: [
      { name: "T-Shirt", price: 25000 },
      { name: "Jeans", price: 40000 },
      { name: "Dress", price: 50000 },
      { name: "Sneakers", price: 60000 },
      { name: "Jacket", price: 80000 },
      { name: "Belt", price: 15000 },
      { name: "Cap / Hat", price: 10000 },
      { name: "Socks (pair)", price: 5000 },
      { name: "Handbag", price: 30000 },
      { name: "Suit (full)", price: 150000 },
    ],
  },
  {
    id: "Electronics & Gadgets",
    label: "Electronics & Gadgets",
    icon: Smartphone,
    color: { bg: "bg-sky-500/10", text: "text-sky-500" },
    products: [
      { name: "Phone Case", price: 10000 },
      { name: "Charger (universal)", price: 20000 },
      { name: "Earphones", price: 15000 },
      { name: "Power Bank (10000mAh)", price: 35000 },
      { name: "USB Cable", price: 8000 },
      { name: "Screen Protector", price: 5000 },
      { name: "Bluetooth Speaker", price: 40000 },
      { name: "Smartwatch", price: 80000 },
      { name: "Memory Card 32GB", price: 15000 },
      { name: "Mouse & Keyboard", price: 30000 },
    ],
  },
  {
    id: "Beauty & Personal Care",
    label: "Beauty & Personal Care",
    icon: Sparkles,
    color: { bg: "bg-pink-500/10", text: "text-pink-500" },
    products: [
      { name: "Hair Oil", price: 10000 },
      { name: "Shampoo", price: 12000 },
      { name: "Body Lotion", price: 8000 },
      { name: "Lipstick", price: 15000 },
      { name: "Nail Polish", price: 5000 },
      { name: "Perfume", price: 25000 },
      { name: "Face Cream", price: 15000 },
      { name: "Deodorant", price: 10000 },
      { name: "Hair Dryer", price: 50000 },
      { name: "Makeup Kit", price: 35000 },
    ],
  },
  {
    id: "Home & Kitchen",
    label: "Home & Kitchen",
    icon: Flame,
    color: { bg: "bg-orange-500/10", text: "text-orange-500" },
    products: [
      { name: "Cooking Pot", price: 30000 },
      { name: "Frying Pan", price: 20000 },
      { name: "Plate Set (4 pcs)", price: 25000 },
      { name: "Water Jug", price: 10000 },
      { name: "Broom", price: 5000 },
      { name: "Buckets", price: 8000 },
      { name: "Cleaning Cloth", price: 3000 },
      { name: "Dish Soap", price: 3000 },
      { name: "Storage Containers", price: 12000 },
      { name: "Mop", price: 10000 },
    ],
  },
  {
    id: "Hardware & Building",
    label: "Hardware & Building",
    icon: Wrench,
    color: { bg: "bg-stone-500/10", text: "text-stone-500" },
    products: [
      { name: "Hammer", price: 15000 },
      { name: "Nails (1kg)", price: 5000 },
      { name: "Paint (1L)", price: 25000 },
      { name: "Pipe (2m)", price: 8000 },
      { name: "Electric Wire (5m)", price: 7000 },
      { name: "Cement (1 bag)", price: 28000 },
      { name: "Screwdriver Set", price: 20000 },
      { name: "Tape Measure", price: 10000 },
      { name: "Glue", price: 5000 },
      { name: "Sandpaper", price: 3000 },
    ],
  },
  {
    id: "Petrol & Fuel",
    label: "Petrol & Fuel",
    icon: Fuel,
    color: { bg: "bg-red-500/10", text: "text-red-500" },
    products: [
      { name: "Petrol (5L)", price: 30000 },
      { name: "Diesel (5L)", price: 28000 },
      { name: "Engine Oil (1L)", price: 20000 },
      { name: "Brake Fluid", price: 15000 },
      { name: "Coolant", price: 12000 },
      { name: "Car Wash Soap", price: 5000 },
    ],
  },
  {
    id: "Agriculture & Garden",
    label: "Agriculture & Garden",
    icon: Sprout,
    color: { bg: "bg-lime-500/10", text: "text-lime-600" },
    products: [
      { name: "Seeds (pack)", price: 5000 },
      { name: "Fertilizer (5kg)", price: 15000 },
      { name: "Pesticide", price: 10000 },
      { name: "Sprayer (5L)", price: 25000 },
      { name: "Animal Feed (5kg)", price: 12000 },
      { name: "Garden Hoe", price: 15000 },
      { name: "Wheelbarrow", price: 80000 },
      { name: "Shovel", price: 20000 },
    ],
  },
  {
    id: "Baby & Kids",
    label: "Baby & Kids",
    icon: Baby,
    color: { bg: "bg-teal-500/10", text: "text-teal-500" },
    products: [
      { name: "Diapers (pack)", price: 25000 },
      { name: "Baby Milk Powder", price: 35000 },
      { name: "Baby Clothes", price: 20000 },
      { name: "Baby Shoes", price: 15000 },
      { name: "Toys", price: 10000 },
      { name: "Baby Soap", price: 3000 },
      { name: "Feeding Bottle", price: 8000 },
      { name: "Baby Blanket", price: 15000 },
    ],
  },
  {
    id: "Books & Stationery",
    label: "Books & Stationery",
    icon: BookOpen,
    color: { bg: "bg-indigo-500/10", text: "text-indigo-500" },
    products: [
      { name: "Exercise Book", price: 2000 },
      { name: "Pen (pack)", price: 3000 },
      { name: "Pencil", price: 1000 },
      { name: "Ruler", price: 1500 },
      { name: "Textbook (subject)", price: 15000 },
      { name: "Stapler", price: 8000 },
      { name: "File / Folder", price: 3000 },
      { name: "A4 Paper (ream)", price: 15000 },
      { name: "Marker Set", price: 5000 },
      { name: "Calculator", price: 20000 },
    ],
  },
  {
    id: "Car & Auto Parts",
    label: "Car & Auto Parts",
    icon: Car,
    color: { bg: "bg-gray-500/10", text: "text-gray-600" },
    products: [
      { name: "Car Battery", price: 180000 },
      { name: "Engine Oil Filter", price: 15000 },
      { name: "Spark Plugs (set)", price: 20000 },
      { name: "Wiper Blades", price: 15000 },
      { name: "Bulb (headlight)", price: 10000 },
      { name: "Car Mat", price: 20000 },
      { name: "Tire Repair Kit", price: 25000 },
      { name: "Seat Cover", price: 30000 },
    ],
  },
  {
    id: "Flowers & Gifts",
    label: "Flowers & Gifts",
    icon: Flower2,
    color: { bg: "bg-rose-500/10", text: "text-rose-500" },
    products: [
      { name: "Flower Bouquet", price: 20000 },
      { name: "Birthday Card", price: 5000 },
      { name: "Gift Wrapping", price: 3000 },
      { name: "Chocolate Box", price: 15000 },
      { name: "Perfume Gift Set", price: 40000 },
      { name: "Teddy Bear", price: 25000 },
      { name: "Birthday Cake", price: 40000 },
    ],
  },
  {
    id: "Sports & Fitness",
    label: "Sports & Fitness",
    icon: Gift,
    color: { bg: "bg-cyan-500/10", text: "text-cyan-500" },
    products: [
      { name: "Football", price: 20000 },
      { name: "Jersey", price: 25000 },
      { name: "Running Shoes", price: 60000 },
      { name: "Water Bottle (sport)", price: 8000 },
      { name: "Dumbbell Set", price: 40000 },
      { name: "Yoga Mat", price: 25000 },
      { name: "Jump Rope", price: 5000 },
      { name: "Gym Bag", price: 15000 },
    ],
  },
  {
    id: "Photography & Print",
    label: "Photography & Print",
    icon: Camera,
    color: { bg: "bg-violet-500/10", text: "text-violet-500" },
    products: [
      { name: "Passport Photo", price: 5000 },
      { name: "Photocopy", price: 500 },
      { name: "Printing (page)", price: 1000 },
      { name: "Scanning", price: 1500 },
      { name: "Binding", price: 5000 },
      { name: "Lamination", price: 3000 },
      { name: "Poster Print", price: 10000 },
    ],
  },
  {
    id: "Salon & Barber",
    label: "Salon & Barber",
    icon: Scissors,
    color: { bg: "bg-fuchsia-500/10", text: "text-fuchsia-500" },
    products: [
      { name: "Haircut", price: 10000 },
      { name: "Shave", price: 5000 },
      { name: "Hair Styling", price: 15000 },
      { name: "Braiding", price: 30000 },
      { name: "Manicure", price: 10000 },
      { name: "Pedicure", price: 10000 },
      { name: "Facial Treatment", price: 20000 },
    ],
  },
  {
    id: "Education & Tutoring",
    label: "Education & Tutoring",
    icon: GraduationCap,
    color: { bg: "bg-blue-400/10", text: "text-blue-400" },
    products: [
      { name: "Tutoring (1hr)", price: 15000 },
      { name: "Notebook Set", price: 8000 },
      { name: "Past Papers", price: 5000 },
      { name: "School Uniform", price: 30000 },
      { name: "School Bag", price: 25000 },
      { name: "Geography Set", price: 12000 },
    ],
  },
  {
    id: "Hotel & Accommodation",
    label: "Hotel & Accommodation",
    icon: Building2,
    color: { bg: "bg-amber-600/10", text: "text-amber-600" },
    products: [
      { name: "Room (per night)", price: 80000 },
      { name: "Breakfast", price: 20000 },
      { name: "Lunch", price: 25000 },
      { name: "Dinner", price: 35000 },
      { name: "Conference Room (hr)", price: 100000 },
      { name: "Laundry Service", price: 15000 },
    ],
  },
  {
    id: "Furniture & Appliances",
    label: "Furniture & Appliances",
    icon: Sofa,
    color: { bg: "bg-amber-700/10", text: "text-amber-700" },
    products: [
      { name: "Sofa Set", price: 350000 },
      { name: "Wardrobe", price: 250000 },
      { name: "Bed Frame", price: 200000 },
      { name: "Mattress (King)", price: 300000 },
      { name: "Dining Table", price: 180000 },
      { name: "Office Chair", price: 90000 },
      { name: "Bookshelf", price: 80000 },
      { name: "Coffee Table", price: 75000 },
      { name: "TV Cabinet", price: 120000 },
      { name: "Refrigerator", price: 1200000 },
      { name: "Washing Machine", price: 950000 },
      { name: "Pressure Cooker", price: 60000 },
      { name: "Blender", price: 90000 },
      { name: "Kettle", price: 45000 },
    ],
  },
  {
    id: "Computers & Accessories",
    label: "Computers & Accessories",
    icon: Laptop,
    color: { bg: "bg-zinc-500/10", text: "text-zinc-600" },
    products: [
      { name: "Laptop Stand", price: 30000 },
      { name: "Headphones", price: 80000 },
      { name: "Wireless Mouse", price: 25000 },
      { name: "Keyboard", price: 40000 },
      { name: "Monitor 22 inch", price: 400000 },
      { name: "Webcam", price: 45000 },
      { name: "Laptop Bag", price: 35000 },
      { name: "USB Hub", price: 25000 },
      { name: "Printer", price: 350000 },
    ],
  },
  {
    id: "Transport & Vehicle Hire",
    label: "Transport & Vehicle Hire",
    icon: CarFront,
    color: { bg: "bg-slate-600/10", text: "text-slate-600" },
    products: [
      { name: "Boda Hire (within town)", price: 3000 },
      { name: "Taxi Hire (local)", price: 15000 },
      { name: "Van Hire (day)", price: 150000 },
      { name: "Truck Hire (day)", price: 250000 },
      { name: "Bus Ticket (city)", price: 5000 },
      { name: "Car Rental (day)", price: 200000 },
    ],
  },
  {
    id: "Travel & Tours",
    label: "Travel & Tours",
    icon: Bus,
    color: { bg: "bg-cyan-600/10", text: "text-cyan-700" },
    products: [
      { name: "City Tour (person)", price: 50000 },
      { name: "Safari (day)", price: 200000 },
      { name: "Hotel Booking", price: 100000 },
      { name: "Airport Transfer", price: 60000 },
      { name: "Boat Cruise", price: 70000 },
      { name: "Camping Gear Hire", price: 30000 },
    ],
  },
  {
    id: "Business Services",
    label: "Business Services",
    icon: Landmark,
    color: { bg: "bg-teal-600/10", text: "text-teal-700" },
    products: [
      { name: "Website Design", price: 300000 },
      { name: "Logo Design", price: 100000 },
      { name: "Accounting Services", price: 150000 },
      { name: "Legal Consult (hr)", price: 100000 },
      { name: "Printing Services", price: 5000 },
      { name: "Marketing Campaign", price: 200000 },
    ],
  },
  {
    id: "Events & Hire Services",
    label: "Events & Hire Services",
    icon: Flame,
    color: { bg: "bg-orange-600/10", text: "text-orange-700" },
    products: [
      { name: "Tent Hire", price: 150000 },
      { name: "Sound System Hire", price: 250000 },
      { name: "Chairs & Tables (set)", price: 50000 },
      { name: "Event Planner (day)", price: 150000 },
      { name: "MC Services", price: 100000 },
      { name: "Catering (per head)", price: 20000 },
    ],
  },
  {
    id: "Delivery & Courier",
    label: "Delivery & Courier",
    icon: Truck,
    color: { bg: "bg-slate-400/10", text: "text-slate-500" },
    products: [
      { name: "Small Parcel (within town)", price: 3000 },
      { name: "Medium Parcel (within town)", price: 5000 },
      { name: "Large Parcel (within town)", price: 8000 },
      { name: "Document Envelope", price: 2000 },
      { name: "Cross-district Parcel", price: 15000 },
      { name: "Same-day Express", price: 10000 },
    ],
  },
];

export const CATEGORY_IDS = CATEGORIES.map((c) => c.id);

/**
 * Resolve a free-text merchant category to a canonical CATEGORIES entry.
 *
 * `merchants.category` is operator-entered free text, not an enum. Real rows
 * contain values like "Furniture " (trailing space) and "Food & Restaurants".
 * Matching on strict equality — which is what this file used to do — therefore
 * missed almost everything and sent people to a grey fallback icon or an empty
 * list. Normalise, then fall back to a substring match either way round so
 * "Groceries" still resolves to "Groceries & Market".
 */
export function matchCategory(raw: string | null | undefined): CategoryInfo | null {
  const s = (raw || "").trim().toLowerCase().replace(/\s*&\s*/g, " & ").replace(/\s+/g, " ");
  if (!s) return null;
  for (const c of CATEGORIES) {
    const id = c.id.toLowerCase();
    if (id === s) return c;
  }
  for (const c of CATEGORIES) {
    const id = c.id.toLowerCase();
    // Compare on the first word ("Groceries" -> "Groceries & Market") before
    // trying the full string, so a short chip still lands on the right entry.
    if (id.startsWith(s + " ") || s.startsWith(id + " ")) return c;
  }
  for (const c of CATEGORIES) {
    const id = c.id.toLowerCase();
    if (id.includes(s) || s.includes(id)) return c;
  }
  return null;
}

/** True when a merchant belongs under the given category chip. */
export function categoryMatches(raw: string | null | undefined, chipId: string): boolean {
  const m = matchCategory(raw);
  return !!m && m.id === chipId;
}

/** Get a category's quick products by its ID */
export function getCategoryProducts(categoryId: string): { name: string; price: number }[] {
  return matchCategory(categoryId)?.products || [];
}

/** Get a category's icon by its ID */
export function getCategoryIcon(categoryId: string): typeof UtensilsCrossed {
  return matchCategory(categoryId)?.icon || ShoppingBag;
}

/** Get a category's color by its ID */
export function getCategoryColor(categoryId: string): { bg: string; text: string } {
  return matchCategory(categoryId)?.color || { bg: "bg-slate-500/10", text: "text-slate-500" };
}
