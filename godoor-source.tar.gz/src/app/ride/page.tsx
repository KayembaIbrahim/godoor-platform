"use client";

import { useState, useEffect, useMemo, useCallback } from "react";
import Link from "next/link";
import dynamic from "next/dynamic";
import { ArrowLeft, MapPin, Navigation, Bike, Phone, X, Loader2, Clock, CheckCircle2 } from "lucide-react";
import { AddressSearchModal } from "@/components/AddressSearchModal";
import { useSession } from "@/lib/session-store";
import { useGeolocation, distanceKm, type LatLng } from "@/lib/location";
import { useRoadRoute } from "@/lib/routing";
import { formatUgx } from "@/lib/utils";
import { createRide, fetchMyRides, fetchRideById, rideAction, subscribeToRide, fetchRiderLocation, subscribeToRiderLocation, type DBRide } from "@/lib/db";
import { StopoverAlert } from "@/components/StopoverAlert";

const LiveTrackingMap = dynamic(() => import("@/components/LiveTrackingMap").then((m) => m.LiveTrackingMap), {
  ssr: false,
  loading: () => <div className="h-64 rounded-2xl bg-surface animate-pulse" />,
});

const BODA_BASE = 2000;
const BODA_PER_KM = 1200;

/** The service-fee rate actually applied to THIS ride, derived from the
 *  stored amounts. A ride priced under an older config must keep showing that
 *  rate, not today's global percentage. Returns null when there is no fee. */
function appliedFeePct(total: number | null | undefined, fee: number | null | undefined): string | null {
  fee = Number(fee ?? 0);
  total = Number(total ?? 0);
  const base = total - fee;
  if (!(base > 0) || !(fee > 0)) return null;
  const pct = (fee / base) * 100;
  return Number.isInteger(pct) ? String(pct) : pct.toFixed(1);
}

function estimateFare(km: number | null): { fare: number; fee: number; total: number } {
  if (km === null || km <= 0) return { fare: 0, fee: 0, total: 0 };
  const fare = Math.max(2500, Math.round(BODA_BASE + km * BODA_PER_KM));
  const fee = Math.round((fare * 5) / 100);
  return { fare, fee, total: fare + fee };
}

type Addr = { place: string; lat: number; lng: number };

/** Statuses that keep a trip in the customer's "active" slot. Anything else
    (completed / cancelled) is history and must free the booking form. */
const LIVE_RIDE_STATUSES: readonly string[] = ["requested", "accepted", "in_progress"];

function ActiveRideCard({ ride: initial, onSettled }: { ride: DBRide; onSettled: (id: string) => void }) {
  const [ride, setRide] = useState(initial);
  const [riderLoc, setRiderLoc] = useState<LatLng | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => { setRide(initial); }, [initial.id]); // eslint-disable-line

  /* Hand the ride back to the parent the moment it settles, so the booking
     form unlocks without waiting for the parent's next poll. */
  useEffect(() => {
    if (!LIVE_RIDE_STATUSES.includes(ride.status)) {
      onSettled(ride.id);
    }
  }, [ride.status, ride.id, onSettled]);

  useEffect(() => {
    const unsub = subscribeToRide(ride.id, (r) => setRide(r));
    const id = setInterval(() => {
      if (document.hidden) return;
      fetchRideById(ride.id).then((r) => { if (r) setRide(r); });
    }, 10000);
    return () => { unsub(); clearInterval(id); };
  }, [ride.id]);

  useEffect(() => {
    if (!ride.rider_id) return;
    fetchRiderLocation(ride.rider_id).then((l) => { if (l) setRiderLoc({ lat: l.lat, lng: l.lng }); });
    const unsub = subscribeToRiderLocation(ride.rider_id, (l) => setRiderLoc({ lat: l.lat, lng: l.lng }));
    return () => { unsub(); };
  }, [ride.rider_id]);

  const pickup = { lat: ride.pickup_lat, lng: ride.pickup_lng };
  const drop = { lat: ride.dropoff_lat, lng: ride.dropoff_lng };
  const { route } = useRoadRoute(pickup, drop);
  const roadCoords = route && route.coordinates.length >= 2 ? route.coordinates : null;

  const cancel = async () => {
    setBusy(true);
    try {
      const r = await rideAction(ride.id, "cancel");
      setRide(r);
    } catch {}
    setBusy(false);
  };

  const settled = !LIVE_RIDE_STATUSES.includes(ride.status);
  const statusLabel =
    ride.status === "requested" ? "Finding your rider…" :
    ride.status === "accepted" ? "Rider on the way to you" :
    ride.status === "in_progress" ? "Trip in progress" :
    ride.status === "completed" ? "Trip completed" : "Ride cancelled";

  /* A settled ride keeps its receipt on screen briefly (so the customer sees
     the outcome) but no longer shows live tracking, which is what made a
     finished trip look like it was still running. */
  if (settled) {
    return (
      <div className="overflow-hidden rounded-2xl border border-success/30 bg-surface">
        <div className="flex items-start gap-3 p-4">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-success/15">
            {ride.status === "completed"
              ? <CheckCircle2 className="h-5 w-5 text-success" />
              : <X className="h-5 w-5 text-danger" />}
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold">{statusLabel}</p>
            <p className="mt-0.5 text-xs text-muted">{ride.pickup_address || "Pickup"} → {ride.dropoff_address || "Dropoff"}</p>
            <p className="num mt-1 text-sm font-bold text-primary tabular-nums">
              {formatUgx(ride.total_ugx)} <span className="text-[10px] font-normal text-dim">{appliedFeePct(ride.total_ugx, ride.service_fee_ugx) ? `incl. ${appliedFeePct(ride.total_ugx, ride.service_fee_ugx)}% service fee` : ""}</span>
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-2xl border border-primary/40 bg-surface">
      <div className="h-[52vh] min-h-[340px] w-full">
        <LiveTrackingMap
          fill
          riderLoc={riderLoc}
          dropoffLoc={drop}
          pickupLoc={pickup}
          showPickup
          roadRoute={roadCoords}
          maneuvers={null}
          showNavigation={false}
          /* The card previously fell back to a distance-based ESTIMATE because
             no quote was passed, so a booked ride showed "FARE UGX 2,000" while
             the trip total below read UGX 4,049. Pass the fare actually agreed
             when the ride was created. */
          quotedFeeUgx={ride.fare_ugx > 0 ? ride.fare_ugx : null}
          label={statusLabel}
          merchantName="Pickup"
          customerName="You"
        />
      </div>
      <div className="p-4">
        <p className="text-sm font-bold">{statusLabel}</p>
        <p className="mt-1 text-xs text-muted">{ride.pickup_address || "Pickup"} → {ride.dropoff_address || "Dropoff"}</p>
        {ride.rider_name ? (
          <p className="mt-1 text-xs text-muted">Rider: <span className="font-semibold text-fg">{ride.rider_name}</span></p>
        ) : (
          <p className="mt-1 text-xs text-muted">Nearby boda riders have been notified.</p>
        )}
        <div className="mt-2 flex items-center justify-between">
          <p className="text-sm font-bold text-primary tabular-nums">{formatUgx(ride.total_ugx)} <span className="text-[10px] font-normal text-dim">{appliedFeePct(ride.total_ugx, ride.service_fee_ugx) ? `incl. ${appliedFeePct(ride.total_ugx, ride.service_fee_ugx)}% service fee` : ""}</span></p>
          {["requested", "accepted"].includes(ride.status) && (
            <button type="button" onClick={cancel} disabled={busy}
              className="rounded-xl bg-danger/10 px-3 py-2 text-xs font-semibold text-danger disabled:opacity-50">
              {busy ? "Cancelling…" : "Cancel ride"}
            </button>
          )}
        </div>
        {/* Declared waiting. Sits directly under the fare: if a rider starts a
            wait, the customer's next question is "what is this costing me",
            and the answer must be on the same screen as the total. */}
        {ride.status === "in_progress" && (
          <div className="mt-3">
            <StopoverAlert rideId={ride.id} active />
          </div>
        )}
      </div>
    </div>
  );
}

export default function RidePage() {
  const { onboarded, profile } = useSession();
  const { coords } = useGeolocation();
  const [pickup, setPickup] = useState<Addr | null>(null);
  const [dropoff, setDropoff] = useState<Addr | null>(null);
  const [modal, setModal] = useState<"pickup" | "dropoff" | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [myRides, setMyRides] = useState<DBRide[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);

  useEffect(() => {
    if (coords && !pickup) setPickup({ place: "My location", lat: coords.lat, lng: coords.lng });
  }, [coords]); // eslint-disable-line

  const loadMine = useCallback(() => {
    fetchMyRides().then((rs) => {
      setMyRides(rs);
      const active = rs.find((r) => LIVE_RIDE_STATUSES.includes(r.status));
      setActiveId(active ? active.id : null);
    }).catch(() => {});
  }, []);

  /* The active ride is derived from a poll, not a one-time read.
     `loadMine` used to run only on mount, so when the rider tapped "Delivered"
     the customer kept seeing "Trip in progress" and the booking form stayed
     blocked behind a trip that no longer existed. Realtime can also silently
     drop, so a poll is the guarantee; it pauses on a hidden tab. */
  useEffect(() => {
    if (!onboarded) return;
    loadMine();
    const tick = () => { if (!document.hidden) loadMine(); };
    const id = setInterval(tick, 10000);
    document.addEventListener("visibilitychange", tick);
    window.addEventListener("focus", tick);
    return () => {
      clearInterval(id);
      document.removeEventListener("visibilitychange", tick);
      window.removeEventListener("focus", tick);
    };
  }, [onboarded, loadMine]);

  const activeRide = myRides.find((r) => r.id === activeId) || null;

  /* A ride that reached a terminal state must release the booking form. This
     is belt-and-braces on top of the poll above, so the user is never trapped
     even if the next poll lands late. */
  useEffect(() => {
    if (activeId && activeRide && !LIVE_RIDE_STATUSES.includes(activeRide.status)) {
      setActiveId(null);
    }
  }, [activeId, activeRide]);

  const km = pickup && dropoff ? distanceKm(pickup, dropoff) : null;
  const est = useMemo(() => estimateFare(km), [km]);
  const previewRoute = useRoadRoute(
    pickup ? { lat: pickup.lat, lng: pickup.lng } : null,
    dropoff ? { lat: dropoff.lat, lng: dropoff.lng } : null,
  );
  const previewCoords = previewRoute.route && previewRoute.route.coordinates.length >= 2
    ? previewRoute.route.coordinates : null;

  const request = async () => {
    if (!pickup || !dropoff || busy) return;
    setBusy(true);
    setError(null);
    try {
      const ride = await createRide({
        customer_name: profile.displayName || profile.name || "Customer",
        customer_phone: (profile as { phone?: string }).phone || "",
        pickup_lat: pickup.lat,
        pickup_lng: pickup.lng,
        pickup_address: pickup.place,
        dropoff_lat: dropoff.lat,
        dropoff_lng: dropoff.lng,
        dropoff_address: dropoff.place,
      });
      setActiveId(ride.id);
      loadMine();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not request ride");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto min-h-screen max-w-lg bg-bg px-4 pb-24 pt-4 md:max-w-4xl">
      <div className="flex items-center gap-3">
        <Link href="/app" aria-label="Back to GoDoor home" className="grid h-9 w-9 place-items-center rounded-full bg-surface text-muted hover:bg-elevated transition">
          <ArrowLeft aria-hidden className="h-4 w-4" />
        </Link>
        <div>
          <h1 className="font-display text-lg font-bold flex items-center gap-2">
            <Bike className="h-5 w-5 text-primary" /> Boda Ride
          </h1>
          <p className="text-[11px] text-muted">Door-to-door boda, tracked live</p>
        </div>
      </div>

      {error && (
        <div className="mt-3 rounded-xl border border-danger/20 bg-danger/10 px-3 py-2.5 flex items-center gap-2">
          <X className="h-4 w-4 text-danger shrink-0" />
          <p className="text-xs text-danger">{error}</p>
        </div>
      )}

      {/* Active ride first — tracking is the hero */}
      {activeRide ? (
        <div className="mt-4">
          <ActiveRideCard ride={activeRide} onSettled={setActiveId} />
          <button type="button" onClick={() => setActiveId(null)}
            className="mt-3 w-full rounded-xl border border-border bg-surface py-2.5 text-xs font-semibold text-muted">
            Book another ride
          </button>
        </div>
      ) : (
        <>
          <div className="md:grid md:grid-cols-[1fr_1.25fr] md:items-start md:gap-4">
          <div>
          {/* Pickup / dropoff */}
          <div className="mt-4 space-y-2 rounded-2xl border border-border bg-surface p-3">
            <button type="button" onClick={() => setModal("pickup")}
              className="flex w-full items-center gap-2.5 rounded-xl bg-elevated/60 px-3 py-3 text-left hover:bg-elevated transition">
              <span className="h-2.5 w-2.5 rounded-full bg-success shrink-0" />
              <span className="min-w-0 flex-1">
                <span className="block text-[10px] uppercase tracking-wider text-dim">Pickup</span>
                <span className="block truncate text-sm font-medium">{pickup?.place || "Choose pickup"}</span>
              </span>
              <MapPin className="h-4 w-4 text-dim shrink-0" />
            </button>
            <button type="button" onClick={() => setModal("dropoff")}
              className="flex w-full items-center gap-2.5 rounded-xl bg-elevated/60 px-3 py-3 text-left hover:bg-elevated transition">
              <span className="h-2.5 w-2.5 rounded-full bg-primary shrink-0" />
              <span className="min-w-0 flex-1">
                <span className="block text-[10px] uppercase tracking-wider text-dim">Dropoff</span>
                <span className="block truncate text-sm font-medium">{dropoff?.place || "Where to?"}</span>
              </span>
              <Navigation className="h-4 w-4 text-dim shrink-0" />
            </button>
          </div>
          </div>
          <div>

          {/* Route preview + fare */}
          {pickup && dropoff && (
            <div className="mt-3 overflow-hidden rounded-2xl border border-border bg-surface">
              <div className="h-56 w-full">
                <LiveTrackingMap
                  fill
                  riderLoc={null}
                  dropoffLoc={{ lat: dropoff.lat, lng: dropoff.lng }}
                  pickupLoc={{ lat: pickup.lat, lng: pickup.lng }}
                  showPickup
                  roadRoute={previewCoords}
      maneuvers={previewRoute.route?.maneuvers ?? null}
                  label="Your route"
                  merchantName="Pickup"
                  customerName="Dropoff"
                />
              </div>
              <div className="grid grid-cols-3 divide-x divide-border p-3 text-center">
                <div>
                  <p className="text-[9px] uppercase tracking-wider text-dim">Distance</p>
                  <p className="text-sm font-bold tabular-nums">{km !== null ? `${km.toFixed(1)} km` : "—"}</p>
                </div>
                <div>
                  <p className="text-[9px] uppercase tracking-wider text-dim">Fare</p>
                  <p className="text-sm font-bold tabular-nums">{formatUgx(est.total)}</p>
                </div>
                <div>
                  <p className="text-[9px] uppercase tracking-wider text-dim">ETA pickup</p>
                  <p className="flex items-center justify-center gap-1 text-sm font-bold"><Clock className="h-3 w-3 text-primary" /> ~10 min</p>
                </div>
              </div>
              <p className="px-3 pb-3 text-[10px] text-dim">{appliedFeePct(est.total, est.fee) ? `Includes ${appliedFeePct(est.total, est.fee)}% GoDoor service fee. Pay the rider directly (GoDoor Wallet).` : "Pay the rider directly (GoDoor Wallet)."}</p>
            </div>
          )}
          </div>
          </div>

          <button type="button" onClick={request} disabled={busy || !pickup || !dropoff || !onboarded}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-3.5 text-sm font-semibold text-white hover:bg-primary-2 transition disabled:opacity-50">
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Bike className="h-4 w-4" />}
            {busy ? "Requesting…" : !onboarded ? "Sign in to request a ride" : "Request boda ride"}
          </button>

          {/* Past rides */}
          {myRides.length > 0 && (
            <div className="mt-5">
              <h3 className="text-sm font-semibold">My rides</h3>
              <div className="mt-2 space-y-2">
                {myRides.slice(0, 5).map((r) => (
                  <button key={r.id} type="button" onClick={() => setActiveId(r.id)}
                    className="flex w-full items-center justify-between rounded-2xl border border-border bg-surface p-3.5 text-left hover:bg-elevated transition">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold">{r.pickup_address || "Pickup"} → {r.dropoff_address || "Dropoff"}</p>
                      <p className="text-[10px] text-muted">{new Date(r.created_at).toLocaleString([], { hour: "2-digit", minute: "2-digit", month: "short", day: "numeric" })} · {formatUgx(r.total_ugx)}</p>
                    </div>
                    <span className="shrink-0 rounded-full bg-elevated px-2 py-0.5 text-[9px] font-bold capitalize text-muted">{r.status.replace("_", " ")}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </>
      )}

      <AddressSearchModal
        open={modal !== null}
        onClose={() => setModal(null)}
        onSelect={(r) => {
          if (modal === "pickup") setPickup(r);
          else if (modal === "dropoff") setDropoff(r);
          setModal(null);
        }}
      />
      <div className="mt-4 flex items-center justify-center gap-3 text-[11px] text-muted">
        <a href="tel:" className="flex items-center gap-1"><Phone className="h-3 w-3" /> Need help? Chat support in Orders</a>
      </div>
    </div>
  );
}
