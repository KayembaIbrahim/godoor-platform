import { NextRequest, NextResponse } from "next/server";
import { getServiceClient } from "@/lib/supabase-server";
import {
  authorize, canTransition, getMerchantForUser, isKnownStatus, isUuid,
} from "@/lib/api-auth";
import { calcDeliveryFee } from "@/lib/utils";
import { resolveFees, serviceFeeFor, splitOrderAmounts } from "@/lib/fees";
import { ensureClinicOrderSchema } from "@/lib/ensure-clinic";
import { holdEscrow } from "@/lib/escrow";
import { verifySpendGrant, walletSecurityEnrolled } from "@/lib/wallet-security";
import { pushToUser } from "@/lib/web-push-server";
import { recordPromoUse, resolvePromoServer } from "@/lib/promo-server";
import { PROMO_REASON_TEXT } from "@/lib/promo";
import { existingColumns } from "@/lib/schema-capabilities";
export const runtime = "nodejs";

const ENSURE_SCHEDULE_COLUMN = `ALTER TABLE orders ADD COLUMN IF NOT EXISTS scheduled_for TIMESTAMPTZ;`;

async function ensureScheduleColumn(sb: NonNullable<ReturnType<typeof getServiceClient>>) {
  try { await sb.rpc("exec_sql", { query: ENSURE_SCHEDULE_COLUMN }); } catch {}
}

/**
 * Order API — every request is authenticated (admin cookie or Supabase JWT).
 * Writes are authorized per role and the order status machine is enforced
 * server-side.
 */

type OrderRow = {
  id: string;
  status: string;
  merchant_id: string | null;
  rider_id: string | null;
  customer_id: string | null;
  customer_email: string | null;
};

async function unauthorized(): Promise<NextResponse> {
  return NextResponse.json({ error: "Sign in to continue" }, { status: 401 });
}

export async function GET(req: NextRequest) {
  const sb = getServiceClient();
  if (!sb) return NextResponse.json({ error: "Not configured" }, { status: 500 });
  const actor = await authorize(req);
  if (!actor) return unauthorized();
  if (actor.kind === "admin") {
    // Admin listing — any order (admin dashboard uses /api/admin/orders, but
    // this path is also used by the shared db layer).
    const { searchParams } = new URL(req.url);
    if (searchParams.get("id")) {
      const { data: single } = await sb.from("orders").select("*").eq("id", searchParams.get("id")).maybeSingle();
      return NextResponse.json({ orders: single ? [single] : [] });
    }
    let q = sb.from("orders").select("*").order("created_at", { ascending: false }).limit(500);
    if (searchParams.get("merchant_id")) q = q.eq("merchant_id", searchParams.get("merchant_id"));
    if (searchParams.get("customer_id")) q = q.eq("customer_id", searchParams.get("customer_id"));
    if (searchParams.get("status")) q = q.eq("status", searchParams.get("status"));
    const { data, error } = await q;
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    return NextResponse.json({ orders: data || [] });
  }

  const user = actor;
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  const customerId = searchParams.get("customer_id");
  const customerEmail = searchParams.get("customer_email");
  const merchantId = searchParams.get("merchant_id");
  const status = searchParams.get("status");

  // Single-order lookup (tracking page) — must belong to the caller
  if (id) {
    const { data: single, error: singleErr } = await sb.from("orders").select("*").eq("id", id).maybeSingle();
    if (singleErr) return NextResponse.json({ error: singleErr.message }, { status: 500 });
    if (!single) return NextResponse.json({ orders: [] });
    const o = single as OrderRow;
    const merchantIdOfCaller = (await getMerchantForUser(sb, user.id))?.id || null;
    const owns =
      o.customer_id === user.id ||
      o.customer_email === user.email ||
      (!!merchantIdOfCaller && o.merchant_id === merchantIdOfCaller) ||
      o.rider_id === user.id;
    if (!owns) return NextResponse.json({ orders: [] }, { status: 404 });
    return NextResponse.json({ orders: [single] });
  }

  // Merchant dashboard scoping — caller must own the requested store (legacy
  // un-owned stores remain accessible to any editor until claimed on first write)
  if (merchantId) {
    if (!isUuid(merchantId)) return NextResponse.json({ orders: [] });
    const { data: merchant, error: merErr } = await sb.from("merchants").select("owner_id").eq("id", merchantId).maybeSingle();
    if (merErr) return NextResponse.json({ orders: [] });
    if (!merchant) return NextResponse.json({ orders: [] });
    const ownerId = (merchant as { owner_id: string | null }).owner_id;
    if (ownerId && ownerId !== user.id) {
      return NextResponse.json({ error: "You do not own this business." }, { status: 403 });
    }
  }
  // Customer scoping — caller may only read their own orders
  if (customerId && customerId !== user.id) {
    return NextResponse.json({ error: "You cannot view another customer's orders." }, { status: 403 });
  }

  let query = sb.from("orders").select("*").order("created_at", { ascending: false }).limit(500);
  if (merchantId) query = query.eq("merchant_id", merchantId);
  if (customerId) query = query.eq("customer_id", customerId);
  if (customerEmail) query = query.eq("customer_email", customerEmail);
  if (status) query = query.eq("status", status);

  // Unfiltered listing is never the whole table. Every signed-in user keeps
  // their full order history across every role they take part in:
  //   - orders they placed as a customer
  //   - orders for merchants they own (business)
  //   - deliveries assigned to them, plus open dispatchable jobs (rider)
  if (!merchantId && !customerId && !customerEmail && !status) {
    const merged = new Map<string, unknown>();
    const stamp = (r: unknown) => new Date((r as { created_at: string }).created_at || 0).getTime();

    const { data: customerOrders } = await sb
      .from("orders").select("*").order("created_at", { ascending: false }).limit(500)
      .or(`customer_id.eq.${user.id},customer_email.eq.${user.email}`);
    for (const o of customerOrders || []) merged.set(String((o as { id: string }).id), o);

    const { data: owned, error: ownedErr } = await sb.from("merchants").select("id").eq("owner_id", user.id);
    if (!ownedErr) {
      for (const m of owned || []) {
        const { data: rows } = await sb.from("orders").select("*").order("created_at", { ascending: false }).eq("merchant_id", String((m as { id: string }).id)).limit(500);
        for (const o of rows || []) merged.set(String((o as { id: string }).id), o);
      }
    }

    const { data: riderRow } = await sb.from("riders").select("id").eq("id", user.id).maybeSingle();
    if (riderRow) {
      // Store riders (business-owned fleets) see ONLY their store's open jobs.
      // Platform riders (no fleet) keep the full dispatch pool.
      let storeFilter = "";
      try {
        const { data: affs } = await sb.from("merchant_riders").select("merchant_id").eq("rider_id", user.id).eq("status", "active");
        const storeIds: string[] = (affs || []).map((a) => String((a as { merchant_id: string }).merchant_id));
        if (storeIds.length) storeFilter = `,and(rider_id.is.null,status.in.(payment_confirmed,preparing,ready,medicines_ready),merchant_id.in.(${storeIds.join(",")}))`;
      } catch {}
      const { data: riderOrders } = await sb.from("orders").select("*").order("created_at", { ascending: false }).limit(500)
        .or(`rider_id.eq.${user.id}${storeFilter || ",and(rider_id.is.null,status.in.(payment_confirmed,preparing,ready,medicines_ready))"}`);
      for (const o of riderOrders || []) merged.set(String((o as { id: string }).id), o);
    }

    const sorted = [...merged.values()].sort((a, b) => stamp(b) - stamp(a)).slice(0, 500);
    return NextResponse.json({ orders: sorted });
  }

  const { data, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ orders: data || [] });
}

const HEADLINE: Record<string, string> = {
  payment_confirmed: "Payment confirmed",
  preparing: "Your order is being prepared",
  ready: "Ready for pickup",
  medicines_ready: "Medicines ready",
  rider_assigned: "A rider has been assigned",
  delivering: "Your order is on the way",
  delivered: "Delivered",
  cancelled: "Order cancelled",
};

/** Best-effort browser push for a status change. Never blocks or fails the
 *  request: a push that does not go out must not stop a delivery progressing. */
async function notifyStatusChange(
  sb: NonNullable<ReturnType<typeof getServiceClient>>,
  orderId: string,
  nextStatus: string,
): Promise<void> {
  try {
    const { data: o } = await sb
      .from("orders")
      .select("id, customer_id, rider_id, merchant_name, items, status")
      .eq("id", orderId)
      .maybeSingle();
    if (!o) return;
    const customerId = o.customer_id as string | null;
    const riderId = o.rider_id as string | null;
    const trackUrl = `/tracking?orderId=${o.id}`;
    const head = HEADLINE[nextStatus] || "Order update";

    if (customerId) {
      await pushToUser(sb, customerId, {
        title: head,
        body: o.items || "Your order was updated",
        url: trackUrl,
        tag: `order-${o.id}`,
      });
    }
    if (riderId && (nextStatus === "ready" || nextStatus === "medicines_ready")) {
      await pushToUser(sb, riderId, {
        title: "New delivery available",
        body: `${o.items || "An order"} at ${o.merchant_name || "a business"} is ready for pickup`,
        url: "/rider",
        tag: `pickup-${o.id}`,
      });
    }
  } catch {
    // Push is a convenience, never a dependency.
  }
}

export async function PATCH(req: NextRequest) {
  const sb = getServiceClient();
  if (!sb) return NextResponse.json({ error: "Not configured" }, { status: 500 });
  const actor = await authorize(req);
  if (!actor) return unauthorized();

  const body = await req.json().catch(() => ({}));
  const { id, patch } = body;
  if (typeof id !== "string" || !patch || typeof patch !== "object") {
    return NextResponse.json({ error: "id and patch required" }, { status: 400 });
  }
  const nextStatus: string | null = typeof patch.status === "string" ? patch.status : null;
  // Self-heal the extended CHECK before any status transition so 'ready' (and future) statuses never violate the constraint
  if (nextStatus) await ensureClinicOrderSchema(sb);
  if (!isUuid(id)) {
    return NextResponse.json({ ok: true }); // local-only order
  }

  const { data: orderRow, error: fetchErr } = await sb.from("orders").select("id, status, merchant_id, rider_id, customer_id, customer_email").eq("id", id).maybeSingle();
  if (fetchErr) return NextResponse.json({ error: fetchErr.message }, { status: 500 });
  if (!orderRow) return NextResponse.json({ error: "Order not found" }, { status: 404 });
  const order = orderRow as OrderRow;
  const riderIdPatch: string | null = typeof patch.rider_id === "string" ? patch.rider_id : null;
  const paymentConfirmedPatch = patch.payment_confirmed !== undefined ? Boolean(patch.payment_confirmed) : undefined;
  const msg = patch.notes !== undefined ? String(patch.notes) : undefined;

  const upd: Record<string, unknown> = { updated_at: new Date().toISOString() };
  const ALLOWED = new Set([
    "status", "notes", "rider_id", "rider_name", "rider_phone", "payment_confirmed",
    "medicine_paid",
  ]);
  for (const k of ALLOWED) {
    if (k in patch) upd[k] = (patch as any)[k];
  }

  if (actor.kind === "admin") {
    if (upd.status !== undefined && !isKnownStatus(upd.status)) {
      return NextResponse.json({ error: `Unknown status "${upd.status}"` }, { status: 400 });
    }
    const { error } = await sb.from("orders").update(upd).eq("id", id);
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    if (upd.status) void notifyStatusChange(sb, id, String(upd.status));
    return NextResponse.json({ ok: true });
  }

  const user = actor;
  const merchantIdOfCaller = (await getMerchantForUser(sb, user.id))?.id || null;
  const decision = canTransition({ order, user, merchantIdOfCaller }, nextStatus, {
    payment_confirmed_patch: paymentConfirmedPatch,
    riderIdPatch: riderIdPatch === user.id ? riderIdPatch : null,
    medicine_paid_patch: body.patch?.medicine_paid === true,
  });
  if (!decision.ok) return NextResponse.json({ error: decision.error }, { status: 403 });

  const userUpd: Record<string, unknown> = { updated_at: new Date().toISOString() };
  if (nextStatus) userUpd.status = nextStatus;
  if (riderIdPatch === user.id) {
    userUpd.rider_id = riderIdPatch;
    if (patch.rider_name) userUpd.rider_name = String(patch.rider_name);
    if (patch.rider_phone) userUpd.rider_phone = String(patch.rider_phone);
  }
  if (paymentConfirmedPatch !== undefined) userUpd.payment_confirmed = Boolean(paymentConfirmedPatch);
  if (body.patch?.medicine_paid === true) userUpd.medicine_paid = true;
  if (msg !== undefined && typeof msg === "string") userUpd.notes = msg;

  if (Object.keys(userUpd).length === 1) return NextResponse.json({ ok: true });

  const { error } = await sb.from("orders").update(userUpd).eq("id", id);
  if (error) {
    console.error("updateOrder API error:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  if (userUpd.status) void notifyStatusChange(sb, id, String(userUpd.status));
  return NextResponse.json({ ok: true });
}

/** Create a new order via server — customer identity is always forced and all
 *  amounts are recomputed server-side from the DB (never trusted from the client). */
export async function POST(req: NextRequest) {
  const sb = getServiceClient();
  if (!sb) return NextResponse.json({ error: "Not configured" }, { status: 500 });
  const actor = await authorize(req);
  if (!actor) return unauthorized();

  const body = await req.json().catch(() => ({}));
  const merchantId = body.merchant_id;
  if (!isUuid(merchantId)) {
    return NextResponse.json({ error: "A valid business is required to place an order" }, { status: 400 });
  }

  await ensureScheduleColumn(sb);

  // The merchant must exist and be active (no orders for vanished/suspended stores)
  const { data: merchant, error: merchantErr } = await sb
    .from("merchants")
    .select("id, name, status, delivery_fee_ugx, lat, lng")
    .eq("id", merchantId)
    .maybeSingle();
  if (merchantErr) return NextResponse.json({ error: merchantErr.message }, { status: 500 });
  if (!merchant) return NextResponse.json({ error: "This business is no longer available" }, { status: 400 });
  // Allow both active and pending businesses to receive orders — pending is auto-activated on first save
  // Only suspended businesses are blocked. This fixes the lazy bug where customers submit but business sees nothing.
  if (merchant.status === "suspended") {
    return NextResponse.json({ error: "This business is temporarily unavailable" }, { status: 400 });
  }
  // Auto-activate pending merchant on first successful order — ensures discoverability
  if (merchant.status === "pending") {
    try { await sb.from("merchants").update({ status: "active" }).eq("id", merchantId); } catch {}
  }

  const status = body.status === "pending" ? "pending" : "payment_submitted";
  const customerId = actor.kind === "admin" && isUuid(body.customer_id) ? body.customer_id : (actor.kind === "user" ? actor.id : null);
  if (!customerId) return NextResponse.json({ error: "Sign in to place an order" }, { status: 401 });

  // ── Server-authoritative pricing ─────────────────────────────────────────
  // Fees come from the fee_config row (fallback to the shared 15% model),
  // line-item prices come from the products table for THIS merchant, and
  // nothing financial is taken from the request body.
  const { data: feeRow } = await sb.from("fee_config").select("*").eq("id", "default").maybeSingle();
  const fees = resolveFees(feeRow as Record<string, unknown> | null);

  // Parse requested line items (only productId, quantity and bulky are taken from the client).
  const requested: Array<{ productId: string; quantity: number; bulky: boolean }> = Array.isArray(body.line_items)
    ? body.line_items.map((li: Record<string, unknown>) => ({
        productId: String(li.productId ?? ""),
        quantity: Math.max(1, Math.floor(Number(li.quantity) || 1)),
        bulky: Boolean(li.bulky),
      }))
    : [];
  const productIds = requested.map((li) => li.productId).filter(Boolean);
  if (productIds.length === 0) {
    return NextResponse.json({ error: "Your cart is empty" }, { status: 400 });
  }

  // Resolve every line item against the products table for this merchant.
  const prices = new Map<string, { price: number; name: string }>();
  for (let i = 0; i < productIds.length; i += 50) {
    const chunk = productIds.slice(i, i + 50);
    const { data: rows } = await sb
      .from("products")
      .select("id, name, price, available")
      .eq("merchant_id", merchantId)
      .in("id", chunk);
    for (const row of rows || []) prices.set(String(row.id), { price: Number(row.price ?? 0), name: String(row.name || "") });
  }

  const lineItems = requested.map((li) => {
    const p = prices.get(li.productId);
    return {
      productId: li.productId,
      merchantId,
      name: p ? p.name : "Item",
      unitPriceUgx: p ? p.price : 0,
      quantity: li.quantity,
      bulky: li.bulky,
    };
  });

  let subtotal = 0;
  for (const li of lineItems) subtotal += li.unitPriceUgx * li.quantity;

  if (subtotal <= 0) {
    return NextResponse.json({ error: "Your cart is empty" }, { status: 400 });
  }
  if (fees.min_order_ugx > 0 && subtotal < fees.min_order_ugx) {
    return NextResponse.json({ error: `Minimum order is UGX ${fees.min_order_ugx.toLocaleString()}` }, { status: 400 });
  }

  const deliveryFee = subtotal >= fees.free_delivery_threshold_ugx
    ? 0
    : (() => {
        // Distance + time billing with day/night minimums
        // (1,500 day · 2,000 from 7pm · 3,000 midnight) instead of a flat fee.
        const mLat = Number((merchant as { lat?: unknown }).lat);
        const mLng = Number((merchant as { lat?: unknown; lng?: unknown }).lng);
        // customerLat/customerLng are parsed below; read raw body here.
        const cLatRaw = Number(body.customer_lat);
        const cLngRaw = Number(body.customer_lng);
        const coordsKnown =
          Number.isFinite(mLat) && Number.isFinite(mLng) &&
          Number.isFinite(cLatRaw) && Number.isFinite(cLngRaw) &&
          cLatRaw >= -1.5 && cLatRaw <= 4.5 && cLngRaw >= 28 && cLngRaw <= 36;
        if (!coordsKnown) {
          return Number(merchant.delivery_fee_ugx ?? fees.delivery_fee_ugx);
        }
        const dLat = ((cLatRaw - mLat) * Math.PI) / 180;
        const dLng = ((cLngRaw - mLng) * Math.PI) / 180;
        const a =
          Math.sin(dLat / 2) ** 2 +
          Math.cos((mLat * Math.PI) / 180) *
            Math.cos((cLatRaw * Math.PI) / 180) *
            Math.sin(dLng / 2) ** 2;
        const km = 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        const bulkyCount = lineItems.reduce((s, li) => s + (li.bulky ? li.quantity : 0), 0);
        return calcDeliveryFee(km, bulkyCount, (km / 25) * 60);
      })();
  const serviceFee = serviceFeeFor(subtotal, feeRow as Record<string, unknown> | null);
  const grossUgx = subtotal + deliveryFee + serviceFee;

  /* ── Promo resolution (server-authoritative) ─────────────────────────────────
     The client sends a CODE, never an amount. It is looked up here against the
     live admin table, so a tampered client can claim a different code but can
     never invent its own discount.

     This used to not exist at all: `total_ugx` was `subtotal + delivery +
     service` and the checkout displayed a discounted figure beside it. The
     customer saw "20% off" and was escrowed at full price. */
  const promo = await resolvePromoServer(sb, {
    code: body.promo_code,
    subtotalUgx: subtotal,
    grossUgx,
  });

  // An unusable code is never fatal. The customer keeps their order at the
  // ordinary price rather than being blocked at the last step — and they are
  // told why, so the banner's claim cannot fail silently.
  const appliedPromo = promo.ok ? promo : null;
  const discountUgx = promo.ok ? promo.discountUgx : 0;
  const totalUgx = promo.ok ? promo.totalUgx : grossUgx;

  const paymentMethod = typeof body.payment_method === "string" ? body.payment_method : "momo";

  // Delivery coordinates must be real — anything missing/out-of-range becomes
  // null (never the (0,0) ocean point) so maps and nav links can't lie.
  const validCoord = (v: unknown, min: number, max: number) => {
    const n = Number(v);
    return Number.isFinite(n) && n >= min && n <= max ? n : null;
  };
  const customerLat = validCoord(body.customer_lat, -1.5, 4.5);
  const customerLng = validCoord(body.customer_lng, 28, 36);

  // Clinic appointments may carry a requested time. Anything unparseable is
  // treated as "now" (ASAP).
  let scheduledFor: string | null = null;
  if (typeof body.scheduled_for === "string" && body.scheduled_for) {
    const t = new Date(body.scheduled_for).getTime();
    if (!Number.isNaN(t)) scheduledFor = new Date(t).toISOString();
  }

  // Idempotency: replaying the same key returns the original order instead of a duplicate.
  const idempotencyKeyRaw = typeof body.idempotency_key === "string" ? body.idempotency_key.slice(0, 128) : "";
  const idempotencyKey = idempotencyKeyRaw || "";

  /* The audit columns (`discount_ugx`, `promo_code`, `promo_label`) were added
     by a migration that has never been applied to production, and PostgREST
     rejects an entire INSERT when it names one unknown key — which is how an
     unfinished migration took every ride-accept down. So they are written only
     when the database actually has them, and the promo is always recorded on
     `notes` (which exists) so an admin can still audit the redemption today. */
  const promoNotes = appliedPromo
    ? `[promo ${appliedPromo.code} ${appliedPromo.promo.type === "percent" ? `${appliedPromo.promo.discount}%` : `UGX ${appliedPromo.promo.discount.toLocaleString()}`} -UGX ${discountUgx.toLocaleString()}]`
    : "";
  const customerNotes = [typeof body.notes === "string" ? body.notes : "", promoNotes]
    .filter(Boolean)
    .join(" ")
    .slice(0, 1000);

  let promoCols = new Set<string>();
  try {
    promoCols = await existingColumns(sb, "orders", ["discount_ugx", "promo_code", "promo_label"]);
  } catch {
    // Probe could not reach a verdict. Strip everything rather than risk
    // rejecting the insert — the discount itself is already in `totalUgx`.
    promoCols = new Set();
  }

  const insertPayload: Record<string, unknown> = {
    merchant_id: merchantId,
    merchant_name: body.merchant_name || merchant.name || "",
    customer_id: customerId,
    customer_name: body.customer_name || "",
    customer_email: actor.kind === "user" ? (actor.email || body.customer_email || "") : (body.customer_email || ""),
    customer_phone: typeof body.customer_phone === "string" ? body.customer_phone : "",
    items: typeof body.items === "string" ? body.items : "",
    line_items: lineItems,
    subtotal_ugx: subtotal,
    delivery_fee_ugx: deliveryFee,
    service_fee_ugx: serviceFee,
    total_ugx: totalUgx,
    delivery_address: typeof body.delivery_address === "string" ? body.delivery_address : "",
    customer_lat: customerLat,
    customer_lng: customerLng,
    status,
    payment_method: paymentMethod,
    payment_confirmed: false,
    notes: customerNotes,
    scheduled_for: scheduledFor,
    idempotency_key: idempotencyKey || null,
  };
  if (promoCols.has("discount_ugx")) insertPayload.discount_ugx = discountUgx;
  if (promoCols.has("promo_code")) insertPayload.promo_code = appliedPromo?.code ?? null;
  if (promoCols.has("promo_label")) insertPayload.promo_label = appliedPromo?.promo.label ?? null;

  const { data, error } = await sb.from("orders").insert(insertPayload).select().single();

  if (error) {
    // Unique idempotency_key collision → return the existing order (idempotent replay).
    if (idempotencyKey && /duplicate key|unique/i.test(String(error.message))) {
      const { data: existing } = await sb
        .from("orders")
        .select("*")
        .eq("idempotency_key", idempotencyKey)
        .maybeSingle();
      if (existing) return NextResponse.json({ order: existing, replayed: true });
    }
    console.error("createOrder API error:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  // ── Escrow hold (wallet payment) ─────────────────────────────────────────
  // When the customer pays from their GoDoor wallet, the money moves into
  // escrow immediately. It is released to the platform + rider only on
  // delivery confirmation, or refunded to the customer on cancel.
  if (paymentMethod === "wallet" && customerId && data) {
    /* ── Wallet authorisation ────────────────────────────────────────────────
       This is the point at which real money leaves the customer's balance, so
       it is the one place a spend grant is checked.

       A wallet that has had a PIN or biometric enrolled MUST present a grant
       minted in the last 90 seconds. The grant is an HMAC-signed, user-scoped
       token verified here on the server — the client-side "I unlocked" flag is
       never consulted, because a React bundle containing that boolean proves
       nothing about who is holding the phone.

       This used to be voluntary: `required` was hardcoded false, so anyone who
       skipped enrolment paid with no authorisation at all while the app still
       showed them a "wallet security" section. Wallet storage now falls back to
       `app_settings`, which does exist in production, so enrolment actually
       works on this database — which is what made mandating it safe.

       The two cases are distinguished deliberately. Someone with nothing
       enrolled is sent to enrolment — they cannot be asked to unlock a PIN they
       never chose — while someone who HAS enrolled cannot skip the check by
       simply not sending the header. */
    if (!(await walletSecurityEnrolled(sb, customerId))) {
      return NextResponse.json(
        {
          error: "Set up a wallet PIN to protect your money",
          code: "WALLET_ENROLMENT_REQUIRED",
        },
        { status: 428 },
      );
    }

    const grant = req.headers.get("x-wallet-grant");
    const method = await verifySpendGrant(grant, customerId);
    if (!method) {
      return NextResponse.json(
        {
          error: "Unlock your wallet to confirm this payment",
          code: "WALLET_LOCK_REQUIRED",
        },
        { status: 428 },
      );
    }

    const escrowResult = await holdEscrow(sb, customerId, String(data.id), totalUgx);
    if (!escrowResult.success) {
      await sb.from("orders").update({ status: "cancelled", notes: "Wallet payment failed — please order again" }).eq("id", data.id);
      return NextResponse.json({
        error: escrowResult.message,
        code: "ESCROW_HOLD_FAILED",
      }, { status: 402 });
    }
    // Store the fee breakdown for admin visibility. Percentages come from the
    // shared model so these columns always agree with release_escrow in SQL.
    const split = splitOrderAmounts(subtotal, deliveryFee);
    await sb.from("orders").update({
      payment_confirmed: true,
      payment_status: "escrowed",
      status: "payment_confirmed",
      service_fee_ugx: split.customerFee,
      business_fee_ugx: split.businessFee,
      rider_fee_ugx: split.riderFee,
      merchant_payout_ugx: split.merchantPayout,
      rider_payout_ugx: split.riderPayout,
      escrow_hold_id: escrowResult.holdId ?? null,
    }).eq("id", data.id);
    Object.assign(data as Record<string, unknown>, {
      payment_confirmed: true,
      payment_status: "escrowed",
      status: "payment_confirmed",
      service_fee_ugx: split.customerFee,
      business_fee_ugx: split.businessFee,
      rider_fee_ugx: split.riderFee,
      merchant_payout_ugx: split.merchantPayout,
      rider_payout_ugx: split.riderPayout,
    });
  }
  /* The redemption is only counted once the order exists. A code can be typed
     on a basket that is abandoned, and an abandoned basket is not a use. */
  if (appliedPromo) {
    void recordPromoUse(sb, appliedPromo.code);
  }

  return NextResponse.json({
    order: data,
    /* Echoed so the confirmation screen can render the figure that was actually
       charged rather than the one it hoped for. */
    promo: appliedPromo
      ? {
          applied: true,
          code: appliedPromo.code,
          label: appliedPromo.promo.label,
          discount_ugx: discountUgx,
          total_ugx: totalUgx,
        }
      : {
          applied: false,
          /* A code was typed but not honoured — say why rather than silently
             charging full price on an order the customer thought was reduced. */
          reason: promo.ok ? null : PROMO_REASON_TEXT[promo.reason],
        },
  });
}